#!/usr/bin/env bash

terraform destroy
